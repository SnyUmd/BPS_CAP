

void Int_DetIn_PE();//PE割込み処理
void Int_DetIn_W();//白割込み処理

void OrderAir(long *aryInfo, long *aryTimeBuf);//割込み時の処理